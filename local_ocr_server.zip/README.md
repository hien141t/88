# TOOL 88VBET AUTO REGISTER & WITHDRAW CHROME EXTENSION

Bộ công cụ Chrome Extension tự động hóa cho `https://m.88vbet08.com`:
1. **Đăng ký tài khoản** tại `https://m.88vbet08.com/Register`
   - Điền Tài khoản: `(//input[@type='text'])[1]`
   - Điền Mật khẩu: `(//input[@type='password'])[1]`
   - Điền Xác nhận MK: `(//input[@type='password'])[2]`
   - Điền Họ tên: `(//input[@type='text'])[2]`
   - Giải Captcha ảnh Base64 (`data:image/png;base64, /9j/...`) bằng `ddddocr` và điền vào `(//input[@type='text'])[3]`
   - Ấn nút đăng ký: `(//button[contains(text(),'Bắt đầu trò chơi')])[1]`
2. **Cài đặt mật khẩu rút tiền & Thêm ngân hàng** tại `https://m.88vbet08.com/Finance/Withdraw`
   - Nhập MK rút tiền: `(//input[@placeholder='Vui lòng nhập mật khẩu rút tiền của bạn'])[1]`
   - Xác nhận MK rút tiền: `(//input[@placeholder='Vui lòng xác nhận lại mật khẩu rút tiền của bạn'])[1]`
   - Ấn nút Gửi đi: `(//button[contains(text(),'Gửi đi')])[1]`
   - Ấn nút Xác nhận: `(//button[contains(text(),'Xác nhận')])[1]`
   - Nhập từ khóa tên ngân hàng: `(//input[@placeholder='--- Vui lòng nhập các từ khóa ---'])[1]`
   - Chọn ngân hàng đích: `(//li[normalize-space()='ABBANK'])[1]` (hoặc ngân hàng chọn trong Popup)
   - Nhập STK: `(//input[@placeholder='Ví dụ: 6227002020690175526'])[1]`
   - Ấn nút Thêm ngân hàng / Gửi đi

---

## 🚀 HƯỚNG DẪN SỬ DỤNG

1. **Khởi động Local OCR Server**:
   - Chạy file `run_local_ocr.bat` (chạy tại `http://127.0.0.1:5588/ocr`).
2. **Cài Extension vào Chrome**:
   - Mở `chrome://extensions` -> Bật **Developer mode** -> Chọn **Load unpacked** -> Chọn thư mục `E:\88vbet`.
3. **Chạy tự động**:
   - Mở Popup tiện ích -> Bấm **⚡ CHẠY ALL** (chạy liên tiếp cả Đăng ký + Cài MK rút tiền + Thêm ngân hàng) hoặc chạy từng phần (**🚀 CHỈ ĐĂNG KÝ** / **💳 MK RÚT & THÊM NH**).
