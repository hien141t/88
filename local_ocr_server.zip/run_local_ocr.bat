@echo off
title 88VBET Local OCR Server
cd /d "%~dp0"
echo ========================================================
echo   Dang khoi dong 88VBET Local OCR Server (ddddocr)...
echo   Endpoint: http://127.0.0.1:5588/ocr
echo ========================================================
python local_ocr_server.py
pause
