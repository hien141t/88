// ==========================================
// 88VBET AUTO - CONTENT SCRIPT
// Hiển thị thẻ thông tin tài khoản nổi (Floating Card) & hỗ trợ DOM
// ==========================================

console.log('[88VBET Content Script] Đã tải trên:', window.location.href);

function showCredentialsFloatingCard(username, password, withdrawPass = '123456') {
    const existing = document.getElementById('vbet88-cred-card');
    if (existing) existing.remove();

    const card = document.createElement('div');
    card.id = 'vbet88-cred-card';
    card.style.cssText = `
        position: fixed;
        bottom: 18px;
        right: 18px;
        z-index: 999999;
        background: rgba(15, 23, 42, 0.96);
        backdrop-filter: blur(10px);
        color: #fff;
        padding: 12px 14px;
        border-radius: 12px;
        box-shadow: 0 8px 32px rgba(0, 0, 0, 0.45);
        border: 1px solid rgba(56, 189, 248, 0.35);
        font-family: system-ui, -apple-system, sans-serif;
        min-width: 240px;
    `;

    card.innerHTML = `
        <div style="font-weight: 700; margin-bottom: 10px; font-size: 13px; color: #38bdf8; display: flex; justify-content: space-between; align-items: center;">
            <span>⚡ TK 88VBET VỪA TẠO</span>
            <span id="vbet88-close-card" style="cursor: pointer; color: #94a3b8; font-size: 18px; line-height: 1;">&times;</span>
        </div>
        <div style="margin-bottom: 7px; font-size: 12px; display: flex; justify-content: space-between; align-items: center; gap: 8px;">
            <div><span style="color: #94a3b8;">TK:</span> <strong style="color: #fff; font-family: monospace; font-size: 13px;">${username}</strong></div>
            <button id="vbet88-copy-user" style="background: #0284c7; border: none; color: #fff; border-radius: 4px; cursor: pointer; font-size: 11px; padding: 2px 8px; font-weight: 600;">Copy</button>
        </div>
        <div style="margin-bottom: 7px; font-size: 12px; display: flex; justify-content: space-between; align-items: center; gap: 8px;">
            <div><span style="color: #94a3b8;">MK:</span> <strong style="color: #fff; font-family: monospace; font-size: 13px;">${password}</strong></div>
            <button id="vbet88-copy-pass" style="background: #0284c7; border: none; color: #fff; border-radius: 4px; cursor: pointer; font-size: 11px; padding: 2px 8px; font-weight: 600;">Copy</button>
        </div>
        <div style="font-size: 12px; display: flex; justify-content: space-between; align-items: center; gap: 8px;">
            <div><span style="color: #94a3b8;">MK Rút:</span> <strong style="color: #f59e0b; font-family: monospace; font-size: 13px;">${withdrawPass}</strong></div>
            <button id="vbet88-copy-wpass" style="background: #0284c7; border: none; color: #fff; border-radius: 4px; cursor: pointer; font-size: 11px; padding: 2px 8px; font-weight: 600;">Copy</button>
        </div>
        <div id="vbet88-copy-status" style="font-size: 11px; color: #4ade80; text-align: center; margin-top: 4px; min-height: 14px;"></div>
    `;

    document.body.appendChild(card);

    document.getElementById('vbet88-close-card')?.addEventListener('click', () => card.remove());

    const copyText = (txt, label) => {
        navigator.clipboard.writeText(txt).then(() => {
            const st = document.getElementById('vbet88-copy-status');
            if (st) {
                st.textContent = `Đã sao chép ${label}!`;
                setTimeout(() => { st.textContent = ''; }, 2000);
            }
        });
    };

    document.getElementById('vbet88-copy-user')?.addEventListener('click', () => copyText(username, 'TK'));
    document.getElementById('vbet88-copy-pass')?.addEventListener('click', () => copyText(password, 'MK'));
    document.getElementById('vbet88-copy-wpass')?.addEventListener('click', () => copyText(withdrawPass, 'MK Rút'));
}

window.addEventListener('vbet88-show-cred', (e) => {
    const d = e.detail || {};
    if (d.username && d.password) {
        showCredentialsFloatingCard(d.username, d.password, d.withdrawPass || '123456');
    }
});
