// ==========================================
// 88VBET Auto Register & Withdraw - Popup Controller
// ==========================================

const DEFAULT_WEBSITES = [
    "https://88vbet03.club?p=2020261012287099",
    "https://m.88vbet08.com/Register"
];

function generateRandomUsername(length = 9) {
    const letters = 'abcdefghijklmnopqrstuvwxyz';
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    let result = letters.charAt(Math.floor(Math.random() * letters.length));
    for (let i = 1; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

function generateRandomPassword() {
    const letters = 'abcdefghijklmnopqrstuvwxyz';
    const numbers = '0123456789';
    let res = '';
    for (let i = 0; i < 5; i++) {
        res += letters.charAt(Math.floor(Math.random() * letters.length));
    }
    for (let i = 0; i < 4; i++) {
        res += numbers.charAt(Math.floor(Math.random() * numbers.length));
    }
    return res;
}

function generateRandomName() {
    const firstNames = ['NGUYEN', 'TRAN', 'LE', 'PHAM', 'HOANG', 'HUYNH', 'PHAN', 'VU', 'VO', 'DANG', 'BUI', 'DO', 'NGO', 'DUONG'];
    const middleNames = ['VAN', 'THI', 'MINH', 'DUC', 'HOANG', 'GIA', 'BAO', 'TUAN', 'ANH', 'QUOC', 'HUU', 'THANH', 'XUAN'];
    const lastNames = ['AN', 'BINH', 'CUONG', 'DUNG', 'DAT', 'HA', 'HUNG', 'KHANG', 'LINH', 'PHUONG', 'LONG', 'NAM', 'PHUC', 'TAI', 'TIEN', 'SON'];

    const first = firstNames[Math.floor(Math.random() * firstNames.length)];
    const middle = middleNames[Math.floor(Math.random() * middleNames.length)];
    const last = lastNames[Math.floor(Math.random() * lastNames.length)];
    return `${first} ${middle} ${last}`;
}

function addLog(message, type = 'info') {
    const logBox = document.getElementById('logBox');
    if (!logBox) return;

    const entry = document.createElement('div');
    entry.className = `log-entry log-${type}`;
    const time = new Date().toLocaleTimeString('vi-VN');
    entry.textContent = `[${time}] ${message}`;

    logBox.appendChild(entry);
    logBox.scrollTop = logBox.scrollHeight;
}

async function checkLocalOcrStatus() {
    const badge = document.getElementById('ocrStatusBadge');
    if (!badge) return;
    try {
        const res = await fetch('http://127.0.0.1:5588/health', { signal: AbortSignal.timeout(1800) });
        if (res.ok) {
            badge.textContent = '🟢 OCR Online';
            badge.className = 'ocr-badge online';
            return;
        }
    } catch (e) {}
    badge.textContent = '🔴 OCR Offline';
    badge.className = 'ocr-badge offline';
}

async function loadWebsites() {
    return new Promise(resolve => {
        chrome.storage.local.get(['vbet88Websites'], result => {
            let list = result.vbet88Websites || [];
            if (list.length === 0) {
                list = [...DEFAULT_WEBSITES];
            } else {
                [...DEFAULT_WEBSITES].reverse().forEach(defSite => {
                    if (!list.includes(defSite)) list.unshift(defSite);
                });
            }
            chrome.storage.local.set({ vbet88Websites: list });
            resolve(list);
        });
    });
}

async function initSiteSelectUI() {
    const list = await loadWebsites();
    const select = document.getElementById('siteSelect');
    select.innerHTML = '';
    list.forEach(site => {
        const opt = document.createElement('option');
        opt.value = site;
        opt.textContent = site;
        select.appendChild(opt);
    });
}

function syncPasswordConfirm() {
    const pass = document.getElementById('password').value;
    document.getElementById('confirmPassword').value = pass;
}

function saveState() {
    syncPasswordConfirm();
    const state = {
        username: document.getElementById('username').value,
        password: document.getElementById('password').value,
        withdrawPass: document.getElementById('withdrawPass').value || '123456',
        fullname: document.getElementById('fullname').value,
        siteSelect: document.getElementById('siteSelect').value
    };
    chrome.storage.local.set({ vbet88State: state });
}

function loadState(callback) {
    chrome.storage.local.get(['vbet88State'], async (result) => {
        await initSiteSelectUI();
        if (result.vbet88State) {
            const s = result.vbet88State;
            document.getElementById('username').value = s.username || '';
            document.getElementById('password').value = s.password || '';
            document.getElementById('confirmPassword').value = s.password || '';
            document.getElementById('withdrawPass').value = '123456';
            document.getElementById('fullname').value = s.fullname || '';
            if (s.siteSelect) document.getElementById('siteSelect').value = s.siteSelect;
            if (callback) callback(true);
        } else {
            if (callback) callback(false);
        }
    });
}

function setRandomAll() {
    const username = generateRandomUsername(9);
    const pass = generateRandomPassword();
    document.getElementById('username').value = username;
    document.getElementById('password').value = pass;
    document.getElementById('confirmPassword').value = pass;
    document.getElementById('withdrawPass').value = '123456';
    document.getElementById('fullname').value = generateRandomName();

    saveState();
    addLog(`Đã tạo ngẫu nhiên TK: ${username}`, 'success');
}

function renderSavedAccounts() {
    chrome.storage.local.get(['savedAccounts88vbet'], (result) => {
        const list = result.savedAccounts88vbet || [];
        const countEl = document.getElementById('savedAccCount');
        const listEl = document.getElementById('savedAccList');
        if (!countEl || !listEl) return;

        countEl.textContent = list.length;
        if (list.length === 0) {
            listEl.innerHTML = '<div style="color: #64748b; text-align: center; padding: 6px;">Chưa có tài khoản nào được lưu.</div>';
            return;
        }

        let html = '';
        list.forEach((acc, idx) => {
            html += `<div style="padding: 4px 0; border-bottom: 1px dashed #1f293d; color: #cbd5e1;">
                <div>
                    <span style="color:#38bdf8;font-weight:bold;">#${idx + 1} TK:</span> ${acc.username} |
                    <span style="color:#f59e0b;">MK:</span> ${acc.password} |
                    <span style="color:#ec4899;">MK Rút:</span> ${acc.withdrawPass || '123456'}
                </div>
                <div style="font-size:9.5px;color:#64748b;">
                    Tên: ${acc.fullname || ''} | Site: ${acc.site || ''}
                </div>
            </div>`;
        });
        listEl.innerHTML = html;
    });
}

async function getActiveTab() {
    const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
    let tab = tabs.find(t => t.url && !t.url.startsWith('chrome-extension://')) || tabs[0];
    if (!tab) {
        tab = await chrome.tabs.create({ url: DEFAULT_WEBSITES[0] });
    }
    return tab;
}

function collectFormData() {
    let username = document.getElementById('username').value.trim();
    if (!username) {
        username = generateRandomUsername(9);
        document.getElementById('username').value = username;
    }

    let password = document.getElementById('password').value.trim();
    if (!password) {
        password = generateRandomPassword();
        document.getElementById('password').value = password;
        document.getElementById('confirmPassword').value = password;
    }

    let withdrawPass = document.getElementById('withdrawPass').value.trim() || '123456';
    document.getElementById('withdrawPass').value = withdrawPass;

    let fullname = document.getElementById('fullname').value.trim();
    if (!fullname) {
        fullname = generateRandomName();
        document.getElementById('fullname').value = fullname;
    }

    const site = document.getElementById('siteSelect').value || DEFAULT_WEBSITES[0];
    saveState();

    return { username, password, withdrawPass, fullname, site };
}

document.addEventListener('DOMContentLoaded', () => {
    checkLocalOcrStatus();
    document.getElementById('ocrStatusBadge')?.addEventListener('click', checkLocalOcrStatus);

    loadState((hasState) => {
        if (!hasState) {
            setRandomAll();
        }
    });

    renderSavedAccounts();
    chrome.storage.onChanged.addListener((changes, area) => {
        if (area === 'local' && changes.savedAccounts88vbet) {
            renderSavedAccounts();
        }
    });

    // Thêm / Xóa website (giữ nguyên link gốc không tự nối /Register để hỗ trợ link đại lý tự nhảy)
    document.getElementById('addSiteBtn')?.addEventListener('click', async () => {
        let val = document.getElementById('newSiteInput').value.trim();
        if (!val) return;
        if (!val.startsWith('http://') && !val.startsWith('https://')) {
            val = 'https://' + val;
        }
        const list = await loadWebsites();
        if (!list.includes(val)) {
            list.push(val);
            chrome.storage.local.set({ vbet88Websites: list }, async () => {
                await initSiteSelectUI();
                document.getElementById('siteSelect').value = val;
                document.getElementById('newSiteInput').value = '';
                saveState();
                addLog('Đã thêm link: ' + val, 'success');
            });
        } else {
            document.getElementById('siteSelect').value = val;
            document.getElementById('newSiteInput').value = '';
            saveState();
            addLog('Đã chọn link: ' + val, 'info');
        }
    });

    document.getElementById('deleteSiteBtn')?.addEventListener('click', async () => {
        const select = document.getElementById('siteSelect');
        const val = select.value;
        if (!val) return;
        let list = await loadWebsites();
        list = list.filter(item => item !== val);
        chrome.storage.local.set({ vbet88Websites: list }, async () => {
            await initSiteSelectUI();
            saveState();
            addLog('Đã xóa link: ' + val, 'info');
        });
    });

    // Random từng ô
    document.getElementById('randomAllBtn')?.addEventListener('click', setRandomAll);

    document.getElementById('randomUserBtn')?.addEventListener('click', () => {
        document.getElementById('username').value = generateRandomUsername(9);
        saveState();
    });

    document.getElementById('randomPassBtn')?.addEventListener('click', () => {
        const p = generateRandomPassword();
        document.getElementById('password').value = p;
        document.getElementById('confirmPassword').value = p;
        saveState();
    });

    document.getElementById('randomNameBtn')?.addEventListener('click', () => {
        document.getElementById('fullname').value = generateRandomName();
        saveState();
    });

    // Lưu state khi sửa input
    ['username', 'password', 'withdrawPass', 'fullname', 'siteSelect'].forEach(id => {
        const el = document.getElementById(id);
        if (el) {
            el.addEventListener('input', saveState);
            el.addEventListener('change', saveState);
        }
    });

    // 1. Nút CHẠY ALL (Đăng ký -> Cài MK Rút 123456)
    document.getElementById('runAllBtn')?.addEventListener('click', async () => {
        const data = collectFormData();
        const tab = await getActiveTab();
        addLog(`⚡ Bắt đầu CHẠY ALL cho TK: ${data.username}...`, 'info');
        chrome.runtime.sendMessage({
            action: "runFullSequence",
            tabId: tab.id,
            data: data
        });
    });

    // 2. Nút CHỈ ĐĂNG KÝ
    document.getElementById('registerOnlyBtn')?.addEventListener('click', async () => {
        const data = collectFormData();
        const tab = await getActiveTab();
        addLog(`🚀 Bắt đầu Đăng ký TK: ${data.username}...`, 'info');
        chrome.runtime.sendMessage({
            action: "runRegisterOnly",
            tabId: tab.id,
            data: data
        });
    });

    // 3. Nút CÀI MK RÚT TIỀN
    document.getElementById('withdrawBankBtn')?.addEventListener('click', async () => {
        const data = collectFormData();
        const tab = await getActiveTab();
        addLog(`🔐 Chuyển tới /Finance/Withdraw cài MK rút (${data.withdrawPass})...`, 'info');
        chrome.runtime.sendMessage({
            action: "runWithdrawAndBank",
            tabId: tab.id,
            data: data
        });
    });

    // Copy / Export / Xóa lịch sử
    document.getElementById('copyAllAccBtn')?.addEventListener('click', () => {
        chrome.storage.local.get(['savedAccounts88vbet'], (result) => {
            const list = result.savedAccounts88vbet || [];
            if (list.length === 0) {
                addLog('Chưa có tài khoản nào để copy!', 'error');
                return;
            }
            const text = list.map(a =>
                `TK: ${a.username} | MK: ${a.password} | MK Rút: ${a.withdrawPass || '123456'} | Tên: ${a.fullname}`
            ).join('\n');
            navigator.clipboard.writeText(text).then(() => {
                addLog(`Đã copy ${list.length} tài khoản!`, 'success');
            });
        });
    });

    document.getElementById('exportTxtBtn')?.addEventListener('click', () => {
        chrome.storage.local.get(['savedAccounts88vbet'], (result) => {
            const list = result.savedAccounts88vbet || [];
            if (list.length === 0) {
                addLog('Chưa có tài khoản nào để xuất file!', 'error');
                return;
            }
            const text = list.map(a =>
                `TK: ${a.username} | MK: ${a.password} | MK Rút: ${a.withdrawPass || '123456'} | Tên: ${a.fullname} | Site: ${a.site} | Time: ${a.time}`
            ).join('\n');
            const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `88vbet_accounts_${Date.now()}.txt`;
            a.click();
            URL.revokeObjectURL(url);
            addLog(`Đã tải file TXT (${list.length} TK)!`, 'success');
        });
    });

    document.getElementById('clearAccBtn')?.addEventListener('click', () => {
        if (confirm('Xóa toàn bộ lịch sử tài khoản 88VBET đã lưu?')) {
            chrome.storage.local.set({ savedAccounts88vbet: [] }, () => {
                renderSavedAccounts();
                addLog('Đã xóa lịch sử tài khoản!', 'info');
            });
        }
    });
});
