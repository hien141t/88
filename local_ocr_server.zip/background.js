// ==========================================
// 88VBET Auto Register & Withdraw - Background Service Worker
// Tự động hóa Đăng ký, Giải Captcha Base64 (ddddocr), Cài MK Rút Tiền & Thêm Ngân Hàng
// ==========================================

const DEFAULT_WEBSITES = [
    "https://88vbet03.club?p=2020261012287099",
    "https://m.88vbet08.com/Register"
];

const LOCAL_OCR_SERVER = "http://127.0.0.1:5588";
const REMOTE_OCR_SERVER = "http://180.93.106.208:5588";
const TELEGRAM_TOKEN = "8842737879:AAHRo6o1rArfrW_XgTYvwm-G0Vht5gYYqfI";
const TELEGRAM_CHAT_ID = "6800097551";

chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "runFullSequence") {
        runFullSequence(request.tabId, request.data);
        sendResponse({ started: true });
        return true;
    }
    if (request.action === "runRegisterOnly") {
        runRegisterOnly(request.tabId, request.data);
        sendResponse({ started: true });
        return true;
    }
    if (request.action === "runWithdrawAndBank") {
        runWithdrawAndBankOnly(request.tabId, request.data);
        sendResponse({ started: true });
        return true;
    }
    if (request.action === "getImageBase64") {
        fetch(request.url)
            .then(res => res.ok ? res.blob() : Promise.reject('Network error'))
            .then(blob => {
                const reader = new FileReader();
                reader.onloadend = () => {
                    const b64 = (reader.result || '').split(',')[1]?.trim().replace(/\s+/g, '') || '';
                    sendResponse({ success: true, base64: b64 });
                };
                reader.onerror = () => sendResponse({ success: false });
                reader.readAsDataURL(blob);
            })
            .catch(() => sendResponse({ success: false }));
        return true;
    }
    if (request.action === "solveCaptcha") {
        chrome.storage.local.get(['anticaptchaApiKey', 'customOcrServer'], function (result) {
            const key = result.anticaptchaApiKey || 'KEY-FE85E3114854368D';
            const remoteServer = result.customOcrServer || REMOTE_OCR_SERVER;
            const mode = request.mode || "digits";

            // 1. Ưu tiên gọi Local OCR Server (http://127.0.0.1:5588/ocr)
            fetch(`${LOCAL_OCR_SERVER}/ocr`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ key: key, image: request.image, mode: mode }),
                signal: AbortSignal.timeout(4000)
            })
            .then(res => res.json())
            .then(data => sendResponse(data))
            .catch(() => {
                // 2. Fallback sang Remote OCR Server
                fetch(`${remoteServer}/ocr`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ key: key, image: request.image, mode: mode }),
                    signal: AbortSignal.timeout(5000)
                })
                .then(res => res.json())
                .then(data => sendResponse(data))
                .catch(err => sendResponse({ success: false, error: err.message }));
            });
        });
        return true;
    }
});

// ==========================================
// HELPER FUNCTIONS
// ==========================================

function waitForTabComplete(tabId, timeoutMs = 15000) {
    return new Promise((resolve) => {
        const timeout = setTimeout(() => {
            chrome.tabs.onUpdated.removeListener(listener);
            resolve();
        }, timeoutMs);

        function listener(updatedTabId, info) {
            if (updatedTabId === tabId && info.status === 'complete') {
                clearTimeout(timeout);
                chrome.tabs.onUpdated.removeListener(listener);
                setTimeout(resolve, 1200);
            }
        }
        chrome.tabs.onUpdated.addListener(listener);
    });
}

function normalizeRegisterUrl(siteInput) {
    let site = (siteInput || DEFAULT_WEBSITES[0]).trim();
    if (!site.startsWith('http://') && !site.startsWith('https://')) {
        site = 'https://' + site;
    }
    try {
        const parsed = new URL(site);
        return {
            registerUrl: parsed.toString(),
            origin: parsed.origin,
            withdrawUrl: `${parsed.origin}/Finance/Withdraw`
        };
    } catch (e) {
        return {
            registerUrl: site,
            origin: 'https://m.88vbet08.com',
            withdrawUrl: 'https://m.88vbet08.com/Finance/Withdraw'
        };
    }
}

async function openAndWaitForRegisterPage(tabId, registerUrl) {
    const tab = await chrome.tabs.get(tabId);
    if (!tab.url || !tab.url.toLowerCase().includes('/register')) {
        console.log("[88VBET BG] Mở link:", registerUrl);
        await chrome.tabs.update(tabId, { url: registerUrl });
        await waitForTabComplete(tabId);

        // Chờ link đại lý (VD: https://88vbet03.club?p=...) tự nhảy sang trang /Register
        for (let i = 0; i < 24; i++) {
            const cur = await chrome.tabs.get(tabId);
            if (cur.status === 'complete' && cur.url && cur.url.toLowerCase().includes('/register')) {
                await new Promise(r => setTimeout(r, 800));
                break;
            }
            await new Promise(r => setTimeout(r, 500));
        }
    }
    const finalTab = await chrome.tabs.get(tabId);
    let actualOrigin = 'https://m.88vbet08.com';
    try {
        if (finalTab.url && finalTab.url.startsWith('http')) {
            actualOrigin = new URL(finalTab.url).origin;
        }
    } catch (e) {}
    return {
        origin: actualOrigin,
        withdrawUrl: `${actualOrigin}/Finance/Withdraw`
    };
}

function saveAccountToHistory(accData) {
    chrome.storage.local.get(['savedAccounts88vbet'], (result) => {
        let list = result.savedAccounts88vbet || [];
        const newAcc = {
            username: accData.username,
            password: accData.password,
            withdrawPass: accData.withdrawPass || '123456',
            fullname: accData.fullname || '',
            site: accData.site || 'https://m.88vbet08.com',
            time: new Date().toLocaleString('vi-VN')
        };
        list = list.filter(item => item.username !== newAcc.username);
        list.unshift(newAcc);
        chrome.storage.local.set({ savedAccounts88vbet: list, lastRegistered88vbet: newAcc }, () => {
            console.log("[88VBET BG] Đã lưu tài khoản vào lịch sử:", newAcc.username);
        });
    });
}

let lastTelegramSentKey = '';

function sendTelegramNotification(data, statusTitle = "🟢 88VBET ĐĂNG KÝ MỚI THÀNH CÔNG") {
    const dedupKey = `${data.username || ''}_${data.password || ''}`;
    if (dedupKey && dedupKey === lastTelegramSentKey) {
        console.log("[88VBET BG] Bỏ qua gửi trùng Telegram cho TK:", data.username);
        return;
    }
    lastTelegramSentKey = dedupKey;

    const text = `${statusTitle}\n` +
                 `👤 TK: ${data.username || '-'}\n` +
                 `🔑 MK: ${data.password || '-'}\n` +
                 `🔐 MK Rút: ${data.withdrawPass || '123456'}\n` +
                 `📝 Họ tên: ${data.fullname || '-'}\n` +
                 `🌐 Site: ${data.site || 'https://m.88vbet08.com'}\n` +
                 `⏰ Thời gian: ${new Date().toLocaleString('vi-VN')}`;

    fetch(`https://api.telegram.org/bot${TELEGRAM_TOKEN}/sendMessage`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ chat_id: TELEGRAM_CHAT_ID, text: text })
    }).catch(err => console.warn("[88VBET BG] Telegram error:", err));
}

// ==========================================
// MAIN FLOWS
// ==========================================

async function runRegisterOnly(tabId, data) {
    try {
        console.log("[88VBET BG] Bắt đầu kịch bản Chỉ Đăng Ký...", data);
        const { registerUrl } = normalizeRegisterUrl(data.site);
        const { origin } = await openAndWaitForRegisterPage(tabId, registerUrl);
        data.site = origin;

        let res = null;
        try {
            const results = await chrome.scripting.executeScript({
                target: { tabId: tabId },
                func: fillRegisterFormAndSolveCaptcha88Vbet,
                args: [data.username, data.password, data.fullname]
            });
            res = results?.[0]?.result;
        } catch (scriptErr) {
            console.log("[88VBET BG] Trang chuyển hướng trong lúc thực thi script:", scriptErr.message);
        }

        const afterTab = await chrome.tabs.get(tabId);
        const redirected = afterTab.url && !afterTab.url.toLowerCase().includes('/register');

        if ((res && res.success) || redirected) {
            saveAccountToHistory(data);
            sendTelegramNotification(data, "🟢 88VBET ĐĂNG KÝ MỚI THÀNH CÔNG");
            console.log("[88VBET BG] Hoàn tất đăng ký & đã gửi Telegram:", data.username);
        } else {
            console.warn("[88VBET BG] Đăng ký chưa hoàn tất:", res);
        }
    } catch (err) {
        console.error("[88VBET BG] Lỗi trong runRegisterOnly:", err);
    }
}

async function runFullSequence(tabId, data) {
    try {
        console.log("[88VBET BG] Bắt đầu CHẠY ALL (Đăng ký -> Cài MK Rút -> Thêm Ngân Hàng)...", data);
        const { registerUrl } = normalizeRegisterUrl(data.site);
        const { origin, withdrawUrl } = await openAndWaitForRegisterPage(tabId, registerUrl);
        data.site = origin;

        // Bước 1: Điền form Đăng ký + Giải Captcha + Ấn nút Đăng Ký & Bắt đầu trò chơi
        let regRes = null;
        try {
            const regResults = await chrome.scripting.executeScript({
                target: { tabId: tabId },
                func: fillRegisterFormAndSolveCaptcha88Vbet,
                args: [data.username, data.password, data.fullname]
            });
            regRes = regResults?.[0]?.result;
        } catch (scriptErr) {
            console.log("[88VBET BG] Trang chuyển hướng ngay sau khi bấm Đăng ký:", scriptErr.message);
        }

        // Kiểm tra xem đã đăng ký thành công hoặc đã chuyển trang khỏi /Register chưa
        let redirected = false;
        let finalWithdrawUrl = withdrawUrl;
        for (let i = 0; i < 16; i++) {
            const curTab = await chrome.tabs.get(tabId);
            if (curTab.url && curTab.url.startsWith('http')) {
                try {
                    finalWithdrawUrl = `${new URL(curTab.url).origin}/Finance/Withdraw`;
                } catch (e) {}
            }
            if (curTab.url && !curTab.url.toLowerCase().includes('/register')) {
                redirected = true;
                break;
            }
            if (regRes && regRes.success && i >= 4) {
                break;
            }
            await new Promise(r => setTimeout(r, 500));
        }

        if ((!regRes || !regRes.success) && !redirected) {
            console.warn("[88VBET BG] Đăng ký hoặc giải Captcha thất bại, dừng luồng:", regRes);
            return;
        }

        // Lưu lịch sử & Gửi Telegram DUY NHẤT 1 LẦN ngay khi Đăng ký thành công
        saveAccountToHistory(data);
        sendTelegramNotification(data, "🟢 88VBET ĐĂNG KÝ MỚI THÀNH CÔNG");

        await new Promise(r => setTimeout(r, 1500));

        // Bước 2: Vào link /Finance/Withdraw cài MK rút tiền & thêm ngân hàng
        console.log("[88VBET BG] Chuyển hướng tới trang Rút tiền:", finalWithdrawUrl);
        await chrome.tabs.update(tabId, { url: finalWithdrawUrl });
        await waitForTabComplete(tabId);
        await new Promise(r => setTimeout(r, 1500));

        const withdrawResults = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: withdrawAndAddBankDOMSequence88Vbet,
            args: [{
                withdrawPass: data.withdrawPass || '123456',
                bankName: data.bankName || 'ABBANK',
                bankAccount: data.bankAccount || ''
            }]
        });

        const withdrawRes = withdrawResults?.[0]?.result;
        console.log("[88VBET BG] Kết quả cài MK rút & thêm ngân hàng:", withdrawRes);
    } catch (err) {
        console.error("[88VBET BG] Lỗi trong runFullSequence:", err);
    }
}

async function runWithdrawAndBankOnly(tabId, data) {
    try {
        console.log("[88VBET BG] Bắt đầu kịch bản Cài MK Rút & Thêm Ngân Hàng...", data);
        const tab = await chrome.tabs.get(tabId);
        let targetOrigin = 'https://m.88vbet08.com';
        if (tab.url && tab.url.startsWith('http') && !tab.url.includes('88vbet03.club')) {
            try { targetOrigin = new URL(tab.url).origin; } catch (e) {}
        }
        const withdrawUrl = `${targetOrigin}/Finance/Withdraw`;
        data.site = targetOrigin;

        if (!tab.url || !tab.url.toLowerCase().includes('/finance/withdraw')) {
            await chrome.tabs.update(tabId, { url: withdrawUrl });
            await waitForTabComplete(tabId);
        }
        await new Promise(r => setTimeout(r, 1200));

        const results = await chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: withdrawAndAddBankDOMSequence88Vbet,
            args: [{
                withdrawPass: data.withdrawPass || '123456',
                bankName: data.bankName || 'ABBANK',
                bankAccount: data.bankAccount || ''
            }]
        });

        const res = results?.[0]?.result;
        if (res && res.success) {
            sendTelegramNotification(data, "💳 88VBET CÀI MK RÚT & LIÊN KẾT NGÂN HÀNG");
        }
        console.log("[88VBET BG] Kết quả runWithdrawAndBankOnly:", res);
    } catch (err) {
        console.error("[88VBET BG] Lỗi trong runWithdrawAndBankOnly:", err);
    }
}

// ==========================================
// INJECTED FUNCTION 1: ĐĂNG KÝ & GIẢI CAPTCHA TRÊN /Register
// ==========================================
function fillRegisterFormAndSolveCaptcha88Vbet(username, password, fullname) {
    function getElementByXpath(path) {
        try {
            return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        } catch (e) {
            return null;
        }
    }

    function showToast(msg, bg = '#0284c7') {
        let el = document.getElementById('vbet88-auto-toast');
        if (!el) {
            el = document.createElement('div');
            el.id = 'vbet88-auto-toast';
            el.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:9999999;padding:9px 16px;border-radius:8px;color:#fff;font-family:sans-serif;font-size:13px;font-weight:700;box-shadow:0 4px 16px rgba(0,0,0,0.45);transition:all 0.2s;';
            document.body.appendChild(el);
        }
        el.style.background = bg;
        el.textContent = msg;
    }

    function forceClick(el) {
        if (!el) return false;
        try { el.focus(); } catch (e) {}
        try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true })); } catch (e) {}
        try { el.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true })); } catch (e) {}
        el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true }));
        el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
        try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true })); } catch (e) {}
        try { el.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true })); } catch (e) {}
        el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
        el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
        try { el.click(); } catch (e) {}
        return true;
    }

    function fillInput(element, value, shouldBlur = true) {
        if (!element) return false;
        try { element.focus(); } catch (e) {}
        try { element.click(); } catch (e) {}

        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        if (nativeSetter) {
            nativeSetter.call(element, value);
        } else {
            element.value = value;
        }

        element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'a', keyCode: 65 }));
        element.dispatchEvent(new KeyboardEvent('keypress', { bubbles: true, key: 'a', keyCode: 65 }));
        element.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
        element.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
        element.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a', keyCode: 65 }));
        if (shouldBlur) {
            element.dispatchEvent(new Event('blur', { bubbles: true }));
        }
        return true;
    }

    function extractCaptchaBase64(imgEl) {
        if (!imgEl) return Promise.resolve(null);
        const src = (imgEl.getAttribute('src') || imgEl.src || '').trim();

        // Trường hợp src là 'data:image/png;base64, /9j/4AAQ...' (có thể có dấu cách sau dấu phẩy)
        if (src.startsWith('data:image')) {
            const parts = src.split(',');
            if (parts.length > 1) {
                const cleanB64 = parts.slice(1).join(',').trim().replace(/\s+/g, '');
                if (cleanB64.length > 20) {
                    return Promise.resolve(cleanB64);
                }
            }
        }

        // Trường hợp vẽ qua Canvas
        try {
            const canvas = document.createElement('canvas');
            canvas.width = imgEl.naturalWidth || imgEl.width || 100;
            canvas.height = imgEl.naturalHeight || imgEl.height || 36;
            const ctx = canvas.getContext('2d');
            ctx.drawImage(imgEl, 0, 0);
            const dataUrl = canvas.toDataURL('image/png');
            if (dataUrl && dataUrl.includes(',')) {
                return Promise.resolve(dataUrl.split(',')[1].trim());
            }
        } catch (e) {
            console.warn("[88VBET DOM] Canvas draw fallback:", e);
        }

        return new Promise((resolve) => {
            chrome.runtime.sendMessage({ action: "getImageBase64", url: imgEl.src }, response => {
                if (chrome.runtime.lastError || !response || !response.success) {
                    resolve(null);
                } else {
                    resolve(response.base64);
                }
            });
        });
    }

    function getCaptchaImg(inputCaptcha) {
        // 1. Ưu tiên tìm thẻ img có src='data:image...' nằm cạnh ô nhập captcha (//input[@type='text'])[3]
        if (inputCaptcha) {
            let parent = inputCaptcha.parentElement;
            for (let d = 0; d < 3 && parent; d++) {
                const imgData = parent.querySelector('img[src^="data:image"]');
                if (imgData) return imgData;
                const anyImg = parent.querySelector('img');
                if (anyImg && (anyImg.src || anyImg.getAttribute('src'))) return anyImg;
                parent = parent.parentElement;
            }
        }
        // 2. Tìm theo XPath ảnh base64
        return (
            getElementByXpath("(//form//img[starts-with(@src, 'data:image')])[1]") ||
            getElementByXpath("(//img[starts-with(@src, 'data:image') and contains(@src, '/9j/')])[1]") ||
            getElementByXpath("(//img[starts-with(@src, 'data:image')])[1]") ||
            getElementByXpath("(//form//fieldset[3]//img)[1]") ||
            document.querySelector('form img[src^="data:image"], img[src^="data:image"]')
        );
    }

    const wait = ms => new Promise(r => setTimeout(r, ms));

    return (async () => {
        showToast('⏳ Đang chờ form đăng ký 88VBET...', '#0284c7');

        // Chờ các ô input xuất hiện (tối đa 15 giây)
        let inputTk = null;
        let inputMk = null;
        let inputConfirmMk = null;
        let inputHoTen = null;
        let inputCaptcha = null;

        for (let i = 0; i < 30; i++) {
            // Exact XPaths theo yêu cầu:
            // tk: (//input[@type='text'])[1]
            // mk: (//input[@type='password'])[1]
            // xác nhận mk: (//input[@type='password'])[2]
            // họ tên: (//input[@type='text'])[2]
            // nhập captcha: (//input[@type='text'])[3]
            inputTk = getElementByXpath("(//input[@type='text'])[1]");
            inputMk = getElementByXpath("(//input[@type='password'])[1]");
            inputConfirmMk = getElementByXpath("(//input[@type='password'])[2]");
            inputHoTen = getElementByXpath("(//input[@type='text'])[2]");
            inputCaptcha = getElementByXpath("(//input[@type='text'])[3]");

            if (inputTk && inputMk && inputConfirmMk && inputHoTen && inputCaptcha) {
                break;
            }
            await wait(500);
        }

        if (!inputTk || !inputMk) {
            showToast('❌ Không tìm thấy form đăng ký!', '#ef4444');
            return { success: false, error: 'Không tìm thấy các trường input đăng ký' };
        }

        await wait(600);
        showToast('✍️ Đang điền TK, MK, Họ tên...', '#0284c7');

        // 1. Điền Tài khoản: (//input[@type='text'])[1]
        fillInput(inputTk, username);
        await wait(200);

        // 2. Điền Mật khẩu: (//input[@type='password'])[1]
        fillInput(inputMk, password);
        await wait(200);

        // 3. Điền Xác nhận mật khẩu: (//input[@type='password'])[2]
        if (inputConfirmMk) {
            fillInput(inputConfirmMk, password);
            await wait(200);
        }

        // 4. Điền Họ tên: (//input[@type='text'])[2]
        if (inputHoTen) {
            fillInput(inputHoTen, fullname);
            await wait(200);
        }

        // Kiểm tra lại giá trị đã điền
        if (inputTk.value !== username) fillInput(inputTk, username);
        if (inputMk.value !== password) fillInput(inputMk, password);
        if (inputConfirmMk && inputConfirmMk.value !== password) fillInput(inputConfirmMk, password);
        if (inputHoTen && inputHoTen.value !== fullname) fillInput(inputHoTen, fullname);

        // Hiển thị thông tin tài khoản nổi trên màn hình
        try {
            window.dispatchEvent(new CustomEvent('vbet88-show-cred', {
                detail: { username, password, fullname }
            }));
        } catch (e) {}

        function refreshCaptcha(imgCaptcha) {
            if (!imgCaptcha) return;
            const nextEl = imgCaptcha.nextElementSibling;
            if (nextEl) forceClick(nextEl);
            const parent = imgCaptcha.parentElement;
            if (parent) {
                const icon = parent.querySelector('i, svg, .fa-sync, .fa-redo, .fa-refresh, [class*="refresh" i], [class*="reload" i]');
                if (icon) forceClick(icon);
            }
            forceClick(imgCaptcha);
        }

        function evalMathStringIfNeeded(str) {
            const m = (str || '').trim().match(/^(\d{1,3})\s*([+\-*xX])\s*(\d{1,3})\s*[=\-]?$/);
            if (!m) return str;
            const a = parseInt(m[1], 10);
            const op = m[2].toLowerCase();
            const b = parseInt(m[3], 10);
            if (op === '-') return String(a - b);
            if (op === '+') return String(a + b);
            return String(a * b);
        }

        const getStartBtn = () =>
            getElementByXpath("(//button[contains(text(),'Bắt đầu trò chơi')])[1]") ||
            getElementByXpath("(//button[contains(.,'Bắt đầu trò chơi')])[1]") ||
            getElementByXpath("(//*[contains(text(),'Bắt đầu trò chơi')])[1]");

        const getRegisterBtn = () =>
            getElementByXpath("(//button[contains(.,'Đăng Ký') or contains(.,'Đăng ký') or contains(.,'ĐĂNG KÝ')])[1]") ||
            getElementByXpath("(//button[@type='submit'])[1]") ||
            document.querySelector('form button, button[type="submit"]');

        // 5. Vòng lặp Giải Captcha (Phép tính / Chữ / Số) -> Ấn Đăng Ký -> Ấn Bắt đầu trò chơi
        let captchaText = '';
        if (inputCaptcha) {
            for (let attempt = 1; attempt <= 6; attempt++) {
                showToast(`🔍 Đang giải Captcha (lần ${attempt}/6)...`, '#f59e0b');

                forceClick(inputCaptcha);
                await wait(500);

                let imgCaptcha = null;
                for (let w = 0; w < 10; w++) {
                    imgCaptcha = getCaptchaImg(inputCaptcha);
                    if (imgCaptcha && (imgCaptcha.getAttribute('src') || imgCaptcha.src)) {
                        break;
                    }
                    await wait(250);
                }

                if (!imgCaptcha) {
                    await wait(700);
                    continue;
                }

                const base64 = await extractCaptchaBase64(imgCaptcha);
                if (!base64) {
                    refreshCaptcha(imgCaptcha);
                    await wait(1200);
                    continue;
                }

                const ocrResult = await new Promise(res => {
                    chrome.runtime.sendMessage({
                        action: "solveCaptcha",
                        image: base64,
                        mode: "smart"
                    }, response => {
                        if (chrome.runtime.lastError) res({ success: false });
                        else res(response || { success: false });
                    });
                });

                if (ocrResult && ocrResult.success && ocrResult.text) {
                    let cleaned = evalMathStringIfNeeded(ocrResult.text.trim());
                    cleaned = cleaned.replace(/\s+/g, '');
                    if (cleaned.length >= 1) {
                        captchaText = cleaned;
                        console.log(`[88VBET DOM] Giải Captcha (lần ${attempt}): '${captchaText}' (${ocrResult.detail || ''})`);
                        fillInput(inputCaptcha, captchaText);
                        showToast(`✅ Captcha: ${captchaText} -> Ấn Đăng Ký`, '#10b981');
                        await wait(450);

                        // Ấn nút Đăng Ký trên form
                        const regBtn = getRegisterBtn() || getStartBtn();
                        if (regBtn) {
                            const targetRegBtn = regBtn.closest('button') || regBtn;
                            targetRegBtn.removeAttribute('disabled');
                            targetRegBtn.classList.remove('disabled');
                            forceClick(targetRegBtn);
                        }

                        // Chờ nút (//button[contains(text(),'Bắt đầu trò chơi')])[1] xuất hiện sau khi ấn Đăng Ký
                        let registeredOk = false;
                        for (let check = 0; check < 10; check++) {
                            await wait(400);
                            const btnStart = getStartBtn();
                            if (btnStart && btnStart.offsetParent !== null) {
                                const targetStartBtn = btnStart.closest('button') || btnStart;
                                showToast('🎮 Ấn Bắt đầu trò chơi!', '#10b981');
                                forceClick(targetStartBtn);
                                registeredOk = true;
                                break;
                            }
                            if (!window.location.href.toLowerCase().includes('/register')) {
                                registeredOk = true;
                                break;
                            }
                        }

                        if (registeredOk) {
                            return { success: true, captchaText };
                        }

                        // Nếu chưa thấy 'Bắt đầu trò chơi' (ví dụ báo lỗi sai mã xác minh), đóng popup lỗi nếu có và thử lại
                        const errConfirmBtn = getElementByXpath("(//button[contains(text(),'Xác nhận') or contains(.,'Xác nhận') or contains(.,'Đóng') or contains(.,'OK')])[1]");
                        if (errConfirmBtn && errConfirmBtn.offsetParent !== null) {
                            forceClick(errConfirmBtn);
                            await wait(400);
                        }
                    }
                }

                if (attempt < 6) {
                    refreshCaptcha(imgCaptcha);
                    await wait(1300);
                }
            }
        }

        if (!captchaText) {
            showToast('❌ Không giải được Captcha! Hãy bật run_local_ocr.bat', '#ef4444');
            return { success: false, error: 'Không thể giải captcha' };
        }

        return { success: true, captchaText };
    })();
}

// ==========================================
// INJECTED FUNCTION 2: CÀI MK RÚT TIỀN (123456) TRÊN /Finance/Withdraw
// ==========================================
function withdrawAndAddBankDOMSequence88Vbet(config) {
    const withdrawPass = (config && config.withdrawPass) ? config.withdrawPass : '123456';

    function getElementByXpath(path) {
        try {
            return document.evaluate(path, document, null, XPathResult.FIRST_ORDERED_NODE_TYPE, null).singleNodeValue;
        } catch (e) {
            return null;
        }
    }

    function showToast(msg, bg = '#0284c7') {
        let el = document.getElementById('vbet88-auto-toast');
        if (!el) {
            el = document.createElement('div');
            el.id = 'vbet88-auto-toast';
            el.style.cssText = 'position:fixed;top:12px;left:50%;transform:translateX(-50%);z-index:9999999;padding:9px 16px;border-radius:8px;color:#fff;font-family:sans-serif;font-size:13px;font-weight:700;box-shadow:0 4px 16px rgba(0,0,0,0.45);transition:all 0.2s;';
            document.body.appendChild(el);
        }
        el.style.background = bg;
        el.textContent = msg;
    }

    function forceClick(el) {
        if (!el) return false;
        try { el.focus(); } catch (e) {}
        try { el.dispatchEvent(new PointerEvent('pointerdown', { bubbles: true, cancelable: true })); } catch (e) {}
        try { el.dispatchEvent(new TouchEvent('touchstart', { bubbles: true, cancelable: true })); } catch (e) {}
        el.dispatchEvent(new MouseEvent('mouseover', { bubbles: true, cancelable: true }));
        el.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, cancelable: true }));
        try { el.dispatchEvent(new PointerEvent('pointerup', { bubbles: true, cancelable: true })); } catch (e) {}
        try { el.dispatchEvent(new TouchEvent('touchend', { bubbles: true, cancelable: true })); } catch (e) {}
        el.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, cancelable: true }));
        el.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true }));
        try { el.click(); } catch (e) {}
        return true;
    }

    function fillInput(element, value, shouldBlur = true) {
        if (!element) return false;
        try { element.focus(); } catch (e) {}
        try { element.click(); } catch (e) {}

        const nativeSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value')?.set;
        if (nativeSetter) {
            nativeSetter.call(element, value);
        } else {
            element.value = value;
        }

        element.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, key: 'a', keyCode: 65 }));
        element.dispatchEvent(new KeyboardEvent('keypress', { bubbles: true, key: 'a', keyCode: 65 }));
        element.dispatchEvent(new Event('input', { bubbles: true, cancelable: true }));
        element.dispatchEvent(new Event('change', { bubbles: true, cancelable: true }));
        element.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true, key: 'a', keyCode: 65 }));
        if (shouldBlur) {
            element.dispatchEvent(new Event('blur', { bubbles: true }));
        }
        return true;
    }

    const wait = ms => new Promise(r => setTimeout(r, ms));

    return (async () => {
        showToast('🔐 Đang chờ form Cài mật khẩu rút tiền...', '#0284c7');

        // mk rút tiền: (//input[@placeholder='Vui lòng nhập mật khẩu rút tiền của bạn'])[1]
        // xác nhận mk rút tiền: (//input[@placeholder='Vui lòng xác nhận lại mật khẩu rút tiền của bạn'])[1]
        // ấn nút gửi đi: (//button[contains(text(),'Gửi đi')])[1]
        // ấn nút xác nhận: (//button[contains(text(),'Xác nhận')])[1]
        let passInput1 = null;
        let passInput2 = null;

        for (let i = 0; i < 25; i++) {
            passInput1 = getElementByXpath("(//input[@placeholder='Vui lòng nhập mật khẩu rút tiền của bạn'])[1]");
            passInput2 = getElementByXpath("(//input[@placeholder='Vui lòng xác nhận lại mật khẩu rút tiền của bạn'])[1]");
            if (passInput1 && passInput2) {
                break;
            }
            await wait(500);
        }

        if (!passInput1 || !passInput2) {
            showToast('⚠️ Không tìm thấy ô nhập mật khẩu rút tiền!', '#f59e0b');
            return { success: false, error: 'Không tìm thấy ô nhập mật khẩu rút tiền' };
        }

        showToast(`✍️ Đang điền MK rút tiền: ${withdrawPass}...`, '#0284c7');
        await wait(400);

        fillInput(passInput1, withdrawPass);
        await wait(250);
        fillInput(passInput2, withdrawPass);
        await wait(500);

        if (passInput1.value !== withdrawPass) fillInput(passInput1, withdrawPass);
        if (passInput2.value !== withdrawPass) fillInput(passInput2, withdrawPass);

        // Ấn nút Gửi đi: (//button[contains(text(),'Gửi đi')])[1]
        const btnGuiDi =
            getElementByXpath("(//button[contains(text(),'Gửi đi')])[1]") ||
            getElementByXpath("(//button[contains(.,'Gửi đi')])[1]") ||
            getElementByXpath("(//button[@type='submit'])[1]");

        if (btnGuiDi) {
            btnGuiDi.removeAttribute('disabled');
            btnGuiDi.classList.remove('disabled');
            showToast('📤 Ấn nút Gửi đi...', '#10b981');
            forceClick(btnGuiDi);
        }

        // Chờ và ấn nút Xác nhận: (//button[contains(text(),'Xác nhận')])[1]
        let btnXacNhan = null;
        for (let j = 0; j < 20; j++) {
            await wait(400);
            btnXacNhan =
                getElementByXpath("(//button[contains(text(),'Xác nhận')])[1]") ||
                getElementByXpath("(//button[contains(.,'Xác nhận')])[1]");
            if (btnXacNhan && btnXacNhan.offsetParent !== null) {
                showToast('✅ Ấn nút Xác nhận!', '#10b981');
                forceClick(btnXacNhan);
                break;
            }
        }

        await wait(600);
        showToast(`🎉 Đã cài đặt MK rút tiền (${withdrawPass}) thành công!`, '#8b5cf6');
        return { success: true };
    })();
}
