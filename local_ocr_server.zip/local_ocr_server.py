"""
Local Captcha OCR Server cho 88VBET Auto Tool
Hỗ trợ giải mọi loại Captcha trên 88vbet:
1. Phép tính toán học (VD: '92 - 89 =' -> '3', '15 + 4 =' -> '19', '6 * 7 =' -> '42')
2. Chuỗi chữ & số hỗn hợp (VD: 'dxdfvg', 'a8k2m')
3. Chuỗi 4 chữ số (VD: '0517')
Endpoint: http://127.0.0.1:5588/ocr
"""

import sys
import re
import base64
import time
import io
import numpy as np
from PIL import Image

if sys.platform == 'win32':
    try:
        sys.stdout.reconfigure(encoding='utf-8', errors='replace')
        sys.stderr.reconfigure(encoding='utf-8', errors='replace')
    except Exception:
        pass

import ddddocr
from flask import Flask, request, jsonify
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

print("[Local OCR] Khởi động ddddocr engines cho 88VBET...")

ocr_digits = ddddocr.DdddOcr(show_ad=False)
try:
    ocr_digits.set_ranges("0123456789")
    print("[Local OCR] ✅ Engine 1: Chuyên giải Số (0-9)")
except Exception as e:
    print(f"[Local OCR] Error setting ranges: {e}")

ocr_alphanumeric = ddddocr.DdddOcr(show_ad=False)
print("[Local OCR] ✅ Engine 2: Giải Chữ + Số + Phép tính (a-z, 0-9, +-*=)")
print("[Local OCR] Ready at http://127.0.0.1:5588 !")


def solve_smart_captcha(image_bytes):
    """
    Tự động nhận diện:
    - Nếu là phép tính (có dấu '=' ở cuối hoặc cấu trúc số [+-*] số =) -> Tính ra kết quả số
    - Nếu là chữ / số thông thường (VD: 'dxdfvg', '0517') -> Trả về chuỗi ký tự
    """
    img = Image.open(io.BytesIO(image_bytes)).convert('RGB')
    W, H = img.size

    raw_alpha = (ocr_alphanumeric.classification(image_bytes) or '').strip()

    # 1. Kiểm tra nếu ddddocr đọc trực tiếp được biểu thức dạng "92-89", "12+5=", "8*3="
    direct_match = re.match(r'^(\d{1,3})\s*([\+\-\*xX])\s*(\d{1,3})\s*[=\-]?$', raw_alpha)
    if direct_match:
        n1 = int(direct_match.group(1))
        op_char = direct_match.group(2).lower()
        n2 = int(direct_match.group(3))
        if op_char == '-':
            ans = n1 - n2
        elif op_char == '+':
            ans = n1 + n2
        else:
            ans = n1 * n2
        return str(ans), f"math_direct({n1}{op_char}{n2}={ans}, raw='{raw_alpha}')"

    # 2. Phân tích các vùng nét chữ (segments) theo trục ngang để phát hiện phép tính "A [+-*] B ="
    gray = np.array(img.convert('L'))
    border_x = 2 if W > 20 else 1
    border_y = 2 if H > 12 else 1
    inner = gray[border_y:H - border_y, border_x:W - border_x]
    dark_mask = inner < 175
    col_counts = dark_mask.sum(axis=0)

    segments = []
    in_seg = False
    start = 0
    for x, c in enumerate(col_counts):
        if c > 0 and not in_seg:
            in_seg = True
            start = x + border_x
        elif c == 0 and in_seg:
            in_seg = False
            if (x + border_x) - start >= 2:
                segments.append((start, x + border_x))
    if in_seg and (W - border_x) - start >= 2:
        segments.append((start, W - border_x))

    seg_info = []
    for sx0, sx1 in segments:
        sub = gray[border_y:H - border_y, sx0:sx1] < 175
        ys = np.where(sub.any(axis=1))[0]
        if len(ys) > 0:
            y0 = int(ys.min() + border_y)
            y1 = int(ys.max() + border_y)
            seg_info.append({
                'x0': sx0,
                'x1': sx1,
                'w': sx1 - sx0,
                'y0': y0,
                'y1': y1,
                'h': y1 - y0 + 1
            })

    # Kiểm tra dấu hiệu biểu thức toán học:
    # - raw_alpha kết thúc bằng '=' hoặc '-' và chứa các chữ số
    # - HOẶC có >= 3 segments tách biệt trên nền trắng sạch, trong đó có 1 segment dấu ở giữa và 1 segment '=' ở cuối
    digits_in_raw = ''.join(c for c in raw_alpha if c.isdigit())
    letters_in_raw = ''.join(c for c in raw_alpha if c.isalpha() and c.lower() not in ('x', 'o', 'i', 'l', 'z', 's'))

    is_math = False
    if (raw_alpha.endswith('=') or raw_alpha.endswith('-') or '=' in raw_alpha) and len(digits_in_raw) >= 2:
        is_math = True
    elif len(seg_info) >= 4 and len(digits_in_raw) >= 2 and len(letters_in_raw) == 0:
        max_h = max(s['h'] for s in seg_info)
        last_s = seg_info[-1]
        mid_ops = [
            s for s in seg_info[1:-1]
            if W * 0.22 <= (s['x0'] + s['x1']) / 2 <= W * 0.75 and s['h'] <= max_h * 0.78
        ]
        if mid_ops and last_s['h'] <= max_h * 0.78:
            is_math = True

    if is_math and len(seg_info) >= 3:
        max_h = max(s['h'] for s in seg_info)
        eq_seg = seg_info[-1]
        candidates = [
            s for s in seg_info[1:-1]
            if W * 0.20 <= (s['x0'] + s['x1']) / 2 <= W * 0.75
        ]
        if candidates:
            op_seg = min(candidates, key=lambda s: s['h'])
            left_crop = img.crop((0, 0, max(1, op_seg['x0'] - 2), H))
            right_crop = img.crop((
                min(W - 1, op_seg['x1'] + 2),
                0,
                max(op_seg['x1'] + 3, eq_seg['x0'] - 2),
                H
            ))

            b1, b2 = io.BytesIO(), io.BytesIO()
            left_crop.save(b1, format='PNG')
            right_crop.save(b2, format='PNG')

            s1 = ''.join(c for c in (ocr_digits.classification(b1.getvalue()) or '') if c.isdigit())
            s2 = ''.join(c for c in (ocr_digits.classification(b2.getvalue()) or '') if c.isdigit())

            if not s1 or not s2:
                if len(digits_in_raw) >= 2:
                    mid = len(digits_in_raw) // 2
                    s1 = s1 or digits_in_raw[:mid]
                    s2 = s2 or digits_in_raw[mid:]

            if s1 and s2:
                n1, n2 = int(s1), int(s2)
                # Phân loại dấu phép tính: '-', '+', '*'
                if op_seg['h'] <= max_h * 0.55:
                    op = '-'
                elif '+' in raw_alpha:
                    op = '+'
                elif 'x' in raw_alpha.lower() or '*' in raw_alpha:
                    op = '*'
                else:
                    sub = (gray[op_seg['y0']:op_seg['y1'] + 1, op_seg['x0']:op_seg['x1'] + 1] < 175).astype(float)
                    sh, sw = sub.shape
                    if sh >= 3 and sw >= 3:
                        corners = (sub[0, 0] + sub[0, -1] + sub[-1, 0] + sub[-1, -1]) / 4.0
                        center_cross = (sub[sh // 2, :].mean() + sub[:, sw // 2].mean()) / 2.0
                        op = '*' if corners > center_cross else '+'
                    else:
                        op = '+'

                ans = (n1 - n2) if op == '-' else ((n1 + n2) if op == '+' else (n1 * n2))
                return str(ans), f"math_seg({n1}{op}{n2}={ans}, raw='{raw_alpha}')"

    # 3. Captcha chữ hoặc số thông thường (VD: 'dxdfvg', '0517')
    cleaned = ''.join(c for c in raw_alpha if c.isalnum())
    if not cleaned:
        raw_d = ocr_digits.classification(image_bytes) or ''
        cleaned = ''.join(c for c in raw_d if c.isalnum())
    return cleaned, f"text(raw='{raw_alpha}' -> '{cleaned}')"


@app.route('/ocr', methods=['POST'])
def solve_captcha():
    """
    Body JSON: { "image": "<base64 hoặc data:image/png;base64, ...>" }
    """
    try:
        data = request.get_json(force=True, silent=True) or {}
        if 'image' not in data:
            return jsonify({'success': False, 'error': 'Thiếu dữ liệu ảnh base64'}), 400

        image_data = (data.get('image') or '').strip()

        if ',' in image_data:
            image_data = image_data.split(',', 1)[1].strip()

        image_data = ''.join(image_data.split())
        if not image_data:
            return jsonify({'success': False, 'error': 'Chuỗi base64 rỗng'}), 400

        missing_padding = len(image_data) % 4
        if missing_padding:
            image_data += '=' * (4 - missing_padding)

        try:
            image_bytes = base64.b64decode(image_data)
        except Exception as b64_err:
            return jsonify({'success': False, 'error': f'Lỗi Base64: {b64_err}'}), 400

        cleaned, debug_info = solve_smart_captcha(image_bytes)
        print(f"[{time.strftime('%H:%M:%S')}] 🎯 OCR 88VBET: {debug_info} => Kết quả='{cleaned}'")

        if not cleaned:
            return jsonify({'success': False, 'error': f'Không nhận dạng được ({debug_info})'}), 422

        return jsonify({'success': True, 'text': cleaned, 'detail': debug_info})

    except Exception as e:
        print(f"[Local OCR] ❌ Lỗi nội bộ: {e}")
        return jsonify({'success': False, 'error': str(e)}), 500


@app.route('/health', methods=['GET'])
def health():
    return jsonify({
        'status': 'ok',
        'engine': 'ddddocr_smart_88vbet',
        'message': '88VBET Smart OCR Server (Số + Chữ + Phép tính)'
    })


if __name__ == '__main__':
    print("=" * 60)
    print("  88VBET Smart Captcha OCR Server (Số + Chữ + Phép tính)")
    print("  Endpoint: http://127.0.0.1:5588/ocr")
    print("=" * 60)
    app.run(host='127.0.0.1', port=5588, debug=False)
